Updated version:

https://github.com/imns1ght/bti-exercises/tree/master/2021.1/multiplayer-gaming

